# DAYFLOW — FINAL KULLANIM SÜRÜMÜ

Bu proje yalnızca HTML önizlemesi değildir: Node.js sunucusu, SQLite kullanıcı hesapları, cihazlar arası eşitleme ve Web Push altyapısı içerir. **Canlı olarak yayımlanmamıştır**; GitHub + Railway kurulumu kullanıcı hesabında yapılmalıdır.

**ÖNEMLİ:** `public/index.html` dosyasını doğrudan çift tıklayarak açarsan e-posta hesabı oluşturamazsın. Siteyi çalışan sunucunun verdiği `https://...` adresinden açmalısın.

## Yerel kullanım
1. Node.js 22+ yükle. ZIP'i tamamen klasöre çıkar (ZIP içinden HTML açma).
2. Proje klasöründe terminal aç: `npm install` ardından `npm start`.
3. Tarayıcıdan `http://localhost:3000` aç. Ayarlar > Hesap bölümünden e-posta ve minimum 8 karakterli parola ile kaydol.
4. Sunucuyu kapatırsan başkaları/telefon bağlantısı kesilir. Kalıcı çevrimiçi erişim için yayınla.

## Canlı yayın — Railway
1. GitHub hesabı oluştur; özel bir repo aç ve ZIP içindeki proje dosyalarını ekle. **`.env` ve veritabanı dosyalarını asla yükleme.**
2. Railway > New Project > Deploy from GitHub Repo > kendi reponu seç.
3. Railway servisinde **Volume** oluştur, örneğin `/data` konumuna bağla. Variables'a `DB_PATH=/data/dayflow.sqlite` yaz. (Volume olmadan redeploy verileri silebilir.)
4. İlk kez bildirim kuruyorsan bilgisayarında `npm install` ve `npm run generate-keys` çalıştır. Railway Variables: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT=mailto:senin-adresin@ornek.com`, `TRUST_PROXY=1`. Anahtarları GitHub'a koyma.
5. Railway > Settings / Networking > Generate Domain. Verilen HTTPS adresini telefon ve bilgisayarda aç. Aynı hesapla giriş yap.
6. Ayarlar > Telefon bildirimlerini aç. iPhone/iPad için önce Safari > Paylaş > Ana Ekrana Ekle, ardından ana ekrandan açıp bildirimleri etkinleştir.
7. `/api/health` adresi `{"ok":true,"service":"dayflow"}` döndürmelidir.

**Sınırlar:** Alarm melodileri uygulama açıkken çalışır; kilitli telefonda yerel saat alarmı gibi garanti edilmez. Spotify müziği otomatik alarm olarak oynatılamaz. TimeEdit iCal bağlantısı sunucu üzerinden elle yenilenir. Çakışan eşzamanlı düzenlemelerde son sunucu sürümü çekilebilir; düzenli JSON yedeği al.

## Yayın öncesi güvenlik
Bu kişisel kullanım için başlangıç sürümüdür, herkese açık bir SaaS olarak güvenlik denetimi yapılmamıştır. Parola sıfırlama, e-posta doğrulama, CSRF koruması, otomatik yedekleme ve yönetilen veritabanı gibi ek korumalar kamusal kullanım için önerilir.

---

# Dayflow v2 — Life Planner

Colorful, Turkish-language weekly planner with user accounts, device sync, and Web Push notifications.

## Requirements
- Node.js 22+
- npm
- HTTPS deployment for background push (localhost works for development)
- Persistent disk storage for `dayflow.sqlite` on your server

## Run locally
```bash
npm install
npm run generate-keys
```
Copy `.env.example` to `.env`, paste the generated VAPID keys, change `VAPID_SUBJECT` to an email address. Load environment variables before starting:
```bash
set -a; source .env; set +a
npm start
```
Open `http://localhost:3000`. To test on a phone, deploy to an HTTPS origin; localhost on your PC does not work from your phone.

## Deployment
Deploy a Node 22 server and attach **persistent storage**. Store `dayflow.sqlite` on persistent storage using `DB_PATH=/path/to/dayflow.sqlite`, use HTTPS via your hosting provider, and supply `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_SUBJECT` environment variables. Use one server instance or a shared storage/database for multiple instances. The service worker must be served from the same origin. On iPhone, add the HTTPS website to the Home Screen (Safari) before enabling push.

## Notes
- Accounts are stored on your server. Passwords are salted and scrypt-hashed; sessions use HTTP-only cookies. Do not publish the SQLite DB or `.env` file.
- Notifications are sent server-side roughly once per 15 seconds during the due minute; delivery timing ultimately depends on operating system and push provider.
- The sync API uses revision checks, avoiding silent overwrites on conflicting simultaneous edits; in a conflict the latest server version is fetched (your unsynced conflicting edits may need re-entry).
- Current sessions last 30 days; this is a starter version, not a fully audited production service. For public launch, add rate limits, password recovery, backups, and CSRF hardening.
- Users can import/export JSON in Settings. Local tasks are imported automatically **when creating a new account**; logging in to an existing account loads the account tasks.


## v5 yenilikleri
- Alışkanlık takipçisi (günlük işaretleme ve seri)
- Pomodoro (25/5/15 ve özel odak süresi)
- Haftalık hedefler ve başarı rozetleri
- Günlük söz ve bilgi yalnızca Planlayıcı sayfasında; tekrar eden Günün odağı kaldırıldı
- Habits, goals ve tamamlanan odak seansları hesap açıldığında settings.lifeFeatures içinde senkronize edilir (sunucu gerektirir).


## Sürüm 6
- Takvimde görevleri başka güne sürükleme (güncelleme sonrası sayfa yenilenir).
- Kategoriye ek özel renk etiketi; görev düzenleme ekranındaki renk seçicisi.
- Ayarlardan sayfa, kart ve sol menü renklerini ayrı değiştirme, kartları gizleme.
- Menü sıralama: masaüstünde sürükle veya ayarlarda yukarı/aşağı okları kullan.
- Alışkanlıklarda son seriye ek en uzun seri ve haftalık işaretler.
- Özelleştirmeler tarayıcıda ve oturumlu senkronizasyonda settings alanında saklanır.
- PWA/push bildirimleri canlı HTTPS sunucu olmadan çalışmaz.


Dayflow v8: Ayarlar ve Alışkanlıklar sayfalarında modüler yerleşim. Kart genişlet/daralt, sırala, sürükle-bırak; tercihler yerelde kaydedilir ve oturum açıldığında settings üzerinden eşitlenir.


## Dayflow 9
Profesyonel temalar ve yerel alarm paneli eklendi. Alarm sesi yalnızca uygulama açıkken çalışır. Spotify bağlantıları kullanıcı tıklamasıyla açılır; Spotify sesini alarm olarak otomatik çalmaz.


## v10: Navigasyon ve TimeEdit
Görünüm, Düzenle, Alarmlar ve Bağlantılar ayrı sol menü sekmeleridir. TimeEdit iCal abone bağlantısı canlı sunucuda /api/timeedit üzerinden okunur; .ics yükleme yerel önizlemede de çalışır. Bütün olaylar salt okunurdur. Şu anda standart VEVENT etkinlikleri içe alınır; karmaşık tekrar kuralları (RRULE), iptaller ve TimeEdit erişimi isteyen gizli akışlar tamamen desteklenmeyebilir.


## v11: Menü sıralaması
Düzenle sayfasında bütün 10 sekme ↑ ↓ veya sürükle-bırak ile sıralanabilir. Sıra dayflow_settings_v1.customize.menuOrder içinde saklanır.


Dayflow 12.0: Ayarlar kartlarının çok dar görünmesine neden olan CSS çakışması giderildi. Yarım genişlik ve tam genişlik düğmeleri korunur; küçük ekranlarda kartlar tam genişlik gösterilir. Mevcut tarayıcı verileri silinmez.


## v13 — Sade kart düzenleme modu
Kart üstü kontrol düğmeleri varsayılan olarak gizlidir. Alışkanlıklar veya Ayarlar sayfasında “Düzeni düzenle” ile açıp kartları genişletin, sıralayın ve sürükleyin. “Düzenlemeyi bitir” ile gizleyin.

## v14 — Görünüm tema geçişi düzeltmesi
Hazır tema seçerken sayfa yenilemesi kaldırıldı. Kullanıcı Görünüm sekmesinde kalır; profesyonel tema kalıntıları temizlenir, yeni tema uygulanır.
