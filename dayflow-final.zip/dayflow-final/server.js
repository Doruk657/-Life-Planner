import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import webpush from 'web-push';

const root = path.resolve(import.meta.dirname, 'public');
const PORT = Number(process.env.PORT || 3000);
const db = new DatabaseSync(process.env.DB_PATH || path.resolve(import.meta.dirname, 'dayflow.sqlite'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,salt TEXT NOT NULL,created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS state(user_id TEXT PRIMARY KEY,payload TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS subscriptions(user_id TEXT NOT NULL,endpoint TEXT NOT NULL,subscription TEXT NOT NULL,PRIMARY KEY(user_id,endpoint));
CREATE TABLE IF NOT EXISTS deliveries(user_id TEXT NOT NULL,event_key TEXT NOT NULL,at INTEGER NOT NULL,PRIMARY KEY(user_id,event_key));`);
const config = {publicKey:process.env.VAPID_PUBLIC_KEY, privateKey:process.env.VAPID_PRIVATE_KEY,subject:process.env.VAPID_SUBJECT};
const pushConfigured = Boolean(config.publicKey&&config.privateKey&&config.subject);
if(pushConfigured) webpush.setVapidDetails(config.subject,config.publicKey,config.privateKey);
function json(res,code,data){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
async function body(req){let parts=[],size=0;for await(const part of req){size+=part.length;if(size>1e6)throw Error('Payload too large');parts.push(part)}return JSON.parse(Buffer.concat(parts).toString('utf8')||'{}')}
function cookie(req){return Object.fromEntries((req.headers.cookie||'').split(';').map(x=>x.trim().split('=').map(decodeURIComponent)).filter(x=>x.length===2))}
function user(req){const token=cookie(req).dayflow_session;if(!token)return null;const hash=crypto.createHash('sha256').update(token).digest('hex');const row=db.prepare('SELECT user_id FROM sessions WHERE token_hash=? AND expires>?').get(hash,Date.now());return row?.user_id||null}
function session(res,id,req){const token=crypto.randomBytes(32).toString('hex');db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'),id,Date.now()+30*86400000);res.setHeader('Set-Cookie',`dayflow_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${(req.socket.encrypted || (process.env.TRUST_PROXY==='1' && req.headers['x-forwarded-proto']==='https'))?' ; Secure':''}`)}
function hashPassword(password,salt){return crypto.scryptSync(password,salt,64).toString('hex')}
const publicUser=id=>{const row=db.prepare('SELECT email FROM users WHERE id=?').get(id);return row?{email:row.email}:null};
const defaultState=()=>({tasks:[],settings:{morning:'08:00',lead:0,timezone:'Europe/Amsterdam'}});
const getState=id=>{const row=db.prepare('SELECT payload,revision FROM state WHERE user_id=?').get(id);return row?{...JSON.parse(row.payload),revision:row.revision}:{...defaultState(),revision:0}};
const attempts=new Map();
function allowAuth(req){
 const ip=(process.env.TRUST_PROXY==='1' ? String(req.headers['x-forwarded-for']||'').split(',')[0].trim() : '') || req.socket.remoteAddress || 'unknown';
 const now=Date.now(), e=attempts.get(ip)||{start:now,n:0};
 if(now-e.start>10*60*1000){e.start=now;e.n=0}
 e.n++;attempts.set(ip,e);return e.n<=35;
}
setInterval(()=>{const now=Date.now();for(const [k,v] of attempts)if(now-v.start>10*60*1000)attempts.delete(k)},600000).unref();
const route=async(req,res,url)=>{
 if(['/api/register','/api/login'].includes(url.pathname)&&req.method==='POST'&&!allowAuth(req))return json(res,429,{error:'Çok fazla deneme yapıldı. Biraz sonra tekrar dene.'});
 if(url.pathname==='/api/timeedit'&&req.method==='GET'){
  const source=url.searchParams.get('url')||'';
  let target;try{target=new URL(source)}catch{return json(res,400,{error:'Invalid URL'})}
  if(target.protocol!=='https:' || !(target.hostname==='timeedit.net'||target.hostname.endsWith('.timeedit.net')) || source.length>4096 || target.port) return json(res,400,{error:'Invalid TimeEdit source'});
  try{const response=await fetch(target,{redirect:'manual',signal:AbortSignal.timeout(10000),headers:{'Accept':'text/calendar, text/plain;q=0.9'}});
  if(!response.ok)return json(res,502,{error:'TimeEdit returned HTTP '+response.status});
  const chunks=[];let bytes=0;for await(const part of response.body){bytes+=part.length;if(bytes>2e6)throw new Error('Calendar too large');chunks.push(part)}
  const calendar=Buffer.concat(chunks).toString('utf8');if(!calendar.includes('BEGIN:VCALENDAR'))return json(res,502,{error:'Response is not iCalendar'});
  res.writeHead(200,{'Content-Type':'text/calendar; charset=utf-8','Cache-Control':'no-store'});return res.end(calendar)
  }catch(e){return json(res,502,{error:'TimeEdit calendar could not be loaded: '+e.message})}
 }
 if(url.pathname==='/api/health'&&req.method==='GET')return json(res,200,{ok:true,service:'dayflow'});
 if(url.pathname==='/api/config'&&req.method==='GET')return json(res,200,{pushConfigured,publicKey:config.publicKey||null});
 if(url.pathname==='/api/register'&&req.method==='POST'){
  const b=await body(req),email=String(b.email||'').trim().toLowerCase(),password=String(b.password||'');
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)||password.length<8||password.length>128)return json(res,400,{error:'Geçerli e-posta ve en az 8 karakterlik parola gerekli.'});
  if(db.prepare('SELECT id FROM users WHERE email=?').get(email))return json(res,409,{error:'Bu e-posta zaten kayıtlı.'});
  const id=crypto.randomUUID(),salt=crypto.randomBytes(16).toString('hex');db.prepare('INSERT INTO users VALUES(?,?,?,?,?)').run(id,email,hashPassword(password,salt),salt,Date.now());
  db.prepare('INSERT INTO state VALUES(?,?,0)').run(id,JSON.stringify(defaultState()));session(res,id,req);return json(res,200,{user:{email},state:getState(id)});
 }
 if(url.pathname==='/api/login'&&req.method==='POST'){
  const b=await body(req),email=String(b.email||'').trim().toLowerCase(),password=String(b.password||'');const found=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  const salt=found?.salt||'00000000000000000000000000000000';const h=hashPassword(password,salt);
  if(!found||!crypto.timingSafeEqual(Buffer.from(h,'hex'),Buffer.from(found.password,'hex')))return json(res,401,{error:'E-posta veya parola hatalı.'});
  session(res,found.id,req);return json(res,200,{user:{email},state:getState(found.id)});
 }
 if(url.pathname==='/api/logout'&&req.method==='POST'){
  const token=cookie(req).dayflow_session;if(token)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(crypto.createHash('sha256').update(token).digest('hex'));
  res.setHeader('Set-Cookie','dayflow_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');return json(res,200,{ok:true});
 }
 const id=user(req);if(!id)return json(res,401,{error:'Önce giriş yap.'});
 if(url.pathname==='/api/me'&&req.method==='GET')return json(res,200,{user:publicUser(id),state:getState(id)});
 if(url.pathname==='/api/state'&&req.method==='GET')return json(res,200,getState(id));
 if(url.pathname==='/api/state'&&req.method==='PUT'){
  const b=await body(req);if(!Array.isArray(b.tasks)||b.tasks.length>3000||!b.settings||!Number.isInteger(b.revision))return json(res,400,{error:'Geçersiz veri.'});
  const tasks=b.tasks.filter(t=>t&&typeof t.id==='string'&&typeof t.title==='string'&&t.title.length<=250&&/^\d{4}-\d\d-\d\d$/.test(t.date||'')&&/^\d\d:\d\d$/.test(t.time||''));
  if(tasks.length!==b.tasks.length)return json(res,400,{error:'Geçersiz görev.'});
  const settings={morning:/^([01]\d|2[0-3]):[0-5]\d$/.test(b.settings.morning)?b.settings.morning:'08:00',lead:Number(b.settings.lead)||0,timezone:String(b.settings.timezone||'Europe/Amsterdam')};
  if(b.settings.lifeFeatures){const f=b.settings.lifeFeatures;if(typeof f==='object'&&Array.isArray(f.habits)&&Array.isArray(f.goals)&&f.habits.length<=150&&f.goals.length<=300){settings.lifeFeatures={habits:f.habits.filter(x=>x&&typeof x.id==='string'&&typeof x.name==='string'&&x.name.length<=65&&Array.isArray(x.days)).map(x=>({id:x.id.slice(0,100),name:x.name,days:x.days.filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)).slice(-365)})),goals:f.goals.filter(x=>x&&typeof x.id==='string'&&typeof x.name==='string'&&x.name.length<=90&&/^\d{4}-\d{2}-\d{2}$/.test(x.week||'')).map(x=>({id:x.id.slice(0,100),name:x.name,week:x.week,done:!!x.done})),sessions:Math.max(0,Math.min(100000,Number(f.sessions)||0))}}}

  try{new Intl.DateTimeFormat('en-US',{timeZone:settings.timezone})}catch{return json(res,400,{error:'Geçersiz saat dilimi.'})}
  const payload=JSON.stringify({tasks,settings});const updated=db.prepare('UPDATE state SET payload=?,revision=revision+1 WHERE user_id=? AND revision=?').run(payload,id,b.revision);
  if(!updated.changes)return json(res,409,{error:'Başka cihazda değişiklik yapıldı.',state:getState(id)});
  return json(res,200,{revision:b.revision+1});
 }
 if(url.pathname==='/api/subscriptions'&&req.method==='POST'){
  if(!pushConfigured)return json(res,503,{error:'Push sunucusu henüz yapılandırılmadı.'});
  const b=await body(req);if(typeof b.endpoint!=='string'||!b.endpoint.startsWith('https://')||!b.keys?.p256dh||!b.keys?.auth)return json(res,400,{error:'Geçersiz abonelik.'});
  db.prepare('INSERT OR REPLACE INTO subscriptions VALUES(?,?,?)').run(id,b.endpoint,JSON.stringify(b));return json(res,200,{ok:true});
 }
 if(url.pathname==='/api/subscriptions'&&req.method==='DELETE'){
  const b=await body(req);db.prepare('DELETE FROM subscriptions WHERE user_id=? AND endpoint=?').run(id,String(b.endpoint||''));return json(res,200,{ok:true});
 }
 return json(res,404,{error:'Bulunamadı.'});
};
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml'};
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost');if(url.pathname.startsWith('/api/'))return await route(req,res,url);if(!['GET','HEAD'].includes(req.method))return json(res,405,{error:'Method not allowed'});
const pathname=url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname);const file=path.resolve(root,'.'+pathname);if(!file.startsWith(root+path.sep))return json(res,403,{error:'Forbidden'});let stat;try{stat=fs.statSync(file)}catch{return json(res,404,{error:'Not found'})}if(!stat.isFile())return json(res,404,{error:'Not found'});res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':pathname==='/sw.js'?'no-cache':'public, max-age=60'});fs.createReadStream(file).pipe(res)
}catch(e){console.error(e);json(res,e.message==='Payload too large'?413:500,{error:'Sunucu hatası.'})}});

function zonedParts(date,tz){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);return Object.fromEntries(parts.map(p=>[p.type,p.value]))}
function zonedEpoch(dateStr,timeStr,tz){const [y,m,d]=dateStr.split('-').map(Number),[h,min]=timeStr.split(':').map(Number);let ms=Date.UTC(y,m-1,d,h,min);for(let i=0;i<3;i++){const p=zonedParts(new Date(ms),tz);const local=Date.UTC(+p.year,+p.month-1,+p.day,+p.hour,+p.minute);ms+=Date.UTC(y,m-1,d,h,min)-local}return ms}
async function deliver(id,key,title,body){const inserted=db.prepare('INSERT OR IGNORE INTO deliveries VALUES(?,?,?)').run(id,key,Date.now());if(!inserted.changes)return;const subs=db.prepare('SELECT endpoint,subscription FROM subscriptions WHERE user_id=?').all(id);for(const s of subs){try{await webpush.sendNotification(JSON.parse(s.subscription),JSON.stringify({title,body,url:'/'}),{TTL:3600})}catch(e){if([404,410].includes(e.statusCode))db.prepare('DELETE FROM subscriptions WHERE user_id=? AND endpoint=?').run(id,s.endpoint);else console.error('Push failed',e.statusCode||e.message)}}}
let busy=false;async function checkSchedule(){if(!pushConfigured||busy)return;busy=true;try{const now=Date.now(),rows=db.prepare('SELECT user_id,payload FROM state').all();for(const row of rows){if(!db.prepare('SELECT 1 FROM subscriptions WHERE user_id=? LIMIT 1').get(row.user_id))continue;const {tasks,settings}=JSON.parse(row.payload);const tz=settings.timezone||'Europe/Amsterdam',p=zonedParts(new Date(now),tz),today=`${p.year}-${p.month}-${p.day}`;const morning=settings.morning||'08:00',morningAt=zonedEpoch(today,morning,tz);if(now>=morningAt&&now-morningAt<60000){const todays=tasks.filter(t=>t.date===today&&!t.done).sort((a,b)=>a.time.localeCompare(b.time));const body=todays.length?todays.slice(0,5).map(t=>`${t.time} ${t.title}`).join(' • '):'Bugün için yeni görev eklemeye ne dersin?';await deliver(row.user_id,`morning:${today}`,'☀️ Günaydın! Bugünkü planın',body)}for(const t of tasks){if(t.done||Number(t.remind)<0||!t.time||!t.date)continue;const at=zonedEpoch(t.date,t.time,tz)-Number(t.remind)*60000;if(now>=at&&now-at<60000)await deliver(row.user_id,`task:${t.id}:${t.date}:${t.time}:${t.remind}`,'⏰ Yaklaşan görev',`${t.time} • ${t.title}`)}}db.prepare('DELETE FROM deliveries WHERE at<?').run(now-45*86400000);db.prepare('DELETE FROM sessions WHERE expires<?').run(now)}catch(e){console.error('Scheduler',e)}finally{busy=false}}
setInterval(checkSchedule,15000);setTimeout(checkSchedule,3000);
server.listen(PORT,()=>console.log(`Dayflow running at http://localhost:${PORT} (push ${pushConfigured?'ready':'not configured'})`));
